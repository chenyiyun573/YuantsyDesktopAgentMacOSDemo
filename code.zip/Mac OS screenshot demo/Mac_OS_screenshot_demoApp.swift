//
//  Mac_OS_screenshot_demoApp.swift
//  Mac OS screenshot demo
//
//  Created by 孟贤泽 on 2024/7/23.
//

import SwiftUI

@main
struct Desktop_agent_demoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()

            
        }
    }
}

    
